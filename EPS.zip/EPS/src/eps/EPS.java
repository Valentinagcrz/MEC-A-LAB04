import java.util.Scanner;
import java.util.Queue;
import java.util.Linkedlist;
        
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eps;

/**
 *
 * @author Estudiante
 */
public class EPS {
     
   static class Paciente {
        String nombre;
        int edad;
        String afiliacion;
        boolean condicionEspecial;
        int tiempoRestante;
   }
   
   public Paciente(String nombre, int edad, String afiliacion, boolean condicionEspecial) {
            this.nombre = nombre;
            this.edad = edad;
            this.afiliacion = afiliacion;
            this.condicionEspecial = condicionEspecial;
            this.tiempoRestante = 300; 
        }
   
   public String toString() {
            return nombre;
        }
    }

    public static void main(String[] args) {
        Queue<Paciente> cola = new LinkedList<>();
        Scanner scanner = new Scanner(System.in);
        int turnoActual = 0;

        while (true) {
            System.out.println("Turno actual: " + turnoActual);
            System.out.println("Tiempo restante: " + (cola.isEmpty() ? "-" : cola.peek().tiempoRestante));
            System.out.println("Pacientes en cola: " + cola);
                }
    /**
     * @param args the command line arguments
     */
  
    
}
